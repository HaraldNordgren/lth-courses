grep "\-\-\-\-\-\-\-\-[[:alnum:]]" HaskoreUtils.hs
