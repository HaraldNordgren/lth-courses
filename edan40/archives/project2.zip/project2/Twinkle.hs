module Twinkle where
import Haskore
import AutoComp
import Chords

cmap f l = chord (map f l)

-- Main Voice:
quarters5 notes = lmap vol [x 5 qn | x <- notes]

v1  = line [v1a, v1b, v1c, v1d]
v1a = quarters5 [c, c, g, g]
v1b = lmap vol [a 5 qn, a 5 qn, g 5 hn]
v1c = quarters5 [f, f, e, e]
v1d = lmap vol [d 5 qn, d 5 qn, c 5 hn]

v2  = line [v2a, v2b, v2c, v2d]
v2a = quarters5 [g, g, f, f]
v2b = lmap vol [e 5 qn, e 5 qn, d 5 hn]
v2c = quarters5 [g, g, f, f]
v2d = lmap vol [e 5 qn, e 5 qn, d 5 hn]

mainVoice = Instr "piano" $ line [v1, v2, v1]


--type Note = (PitchClass, Octave)



--map (trans i (C,3)) ionian
--  where trans i pitch = 


--Chords in Haskore
--[0,2,4] basic triad in major scale

-- Chords:
--ionian     = [0, 2, 4, 5, 7, 9, 11]
--mixolydian = [0, 2, 4, 5, 7, 9, 10]
--lydian     = [0, 2, 4, 6, 7, 9, 11]

-- "chordScale pitch ionian" generates a regular major scale
chordScale pitch = map (flip trans pitch)

makeChord c
  | c == C = majChord (C, 5) ionian
  | c == G = majChord (G, 4) mixolydian
  | c == F = majChord (F, 4) lydian

generateAcc = line . map (chord . map toMusic)
  where toMusic x = Note x hn [Volume 60]

accompaniment = Instr "piano" $ line [acc1, acc2, acc1]
acc1 = generateAcc $ map makeChord [C, C, F, C, G, C, G, C]
acc2 = times 4 $ generateAcc $ map makeChord [C, G]

-- Putting it all together:
--twinkle = Tempo 2.2 $ Phrase [Dyn SF] mainVoice :=: accompaniment :=: bass
twinkle = Tempo 2.2 $ Phrase [Dyn SF] mainVoice :=: accompaniment
