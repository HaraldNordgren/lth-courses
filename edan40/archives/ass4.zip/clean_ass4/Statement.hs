module Statement(T, parse, toString, fromString, exec) where
import Prelude hiding (return, fail, read)
import Parser hiding (T)
import qualified Dictionary
import qualified Expr
type T = Statement
data Statement =
    Assignment String Expr.T |
    Skip |
    Begin [Statement] |
    If Expr.T Statement Statement |
    While Expr.T Statement |
    Read String |
    Write Expr.T
    deriving Show


assignment = (word #- accept ":=") # (Expr.parse #- require ";") >-> buildAss
  where buildAss (v, e) = Assignment v e

skip = accept "skip" #- require ";" >-> buildSkip
  where buildSkip _ = Skip

begin = accept "begin" -# iter parse #- require "end" >-> Begin

ifs = accept "if" -# Expr.parse #- require "then" # parse #- require "else" # parse >-> buildIf
  where buildIf ((e, s1), s2) = If e s1 s2

while = accept "while" -# Expr.parse #- require "do" # parse >-> buildWhile
  where buildWhile (e,s) = While e s

read = accept "read" -# word #- require ";" >-> Read

write = accept "write" -# Expr.parse #- require ";" >-> Write


exec :: [T] -> Dictionary.T String Integer -> [Integer] -> [Integer]
exec [] _ _ = []
exec (Assignment var e:stmts) dict input = exec stmts (Dictionary.insert (var, Expr.value e dict) dict) input
exec (Skip:stmts) dict input = exec stmts dict input
exec (Begin cs:stmts) dict input = exec (cs ++ stmts) dict input
exec (If cond thenStmt elseStmt:stmts) dict input = 
    if Expr.value cond dict > 0 
    then exec (thenStmt:stmts) dict input
    else exec (elseStmt:stmts) dict input
exec (While cond s:stmts) dict input =
    if Expr.value cond dict > 0
    then exec (s:While cond s:stmts) dict input
    else exec stmts dict input
exec (Read s:_) _ [] = error "too few input arguments"
exec (Read s:stmts) dict (nbr:input) = exec stmts (Dictionary.insert (s, nbr) dict) input
exec (Write e:stmts) dict input = Expr.value e dict:exec stmts dict input


toString' i (Assignment s e) = i++s++" := "++toString e++";"
toString' i (Skip) = i++"skip;"
toString' i (Begin stmnts) = i++"begin\n"++ foldr1 (++) (map ((++"\n") . (toString' (i++indent))) stmnts) ++i++"end"
toString' i (If e s1 s2) = i++"if "++toString e++" then\n"++ toString' (i++indent) s1 ++"\n"++i++"else\n"++ toString' (i++indent) s2
toString' i (While e s) = i++"while "++toString e++" do\n"++ toString' (i++indent) s
toString' i (Read string) = i++"read "++string++";"
toString' i (Write e) = i++"write "++toString e++";"

indent = "  "

instance Parse Statement where
  parse = assignment ! skip ! begin ! ifs ! while ! read ! write
  toString e = toString' "" e
