#include "crypto.h"

#include <string>
#include <random>

using namespace std;

string Crypto::encrypt(const string& text, unsigned int key) {
	return "";
}

string Crypto::decrypt(const string& crypt, unsigned int key) {
	return "";
}
