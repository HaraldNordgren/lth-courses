#include "morsecode.h"

#include <fstream>
#include <sstream>

using namespace std;

MorseCode::MorseCode() {
}

string MorseCode::encode(const string& text) const {
	return "";
}

string MorseCode::decode(const string& code) const {
	return "";
}
