#include "editor.h"

#include <string>

using namespace std;

string::size_type Editor::find_left_par(string::size_type pos) const {
	return 0;
}
